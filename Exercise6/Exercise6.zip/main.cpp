#include <iostream>
#include <ferienprogramm.h>

using namespace std;

int main()
{
    Ferienprogramm FP;
    do {
        FP.mainDialog();
    } while(true);
    return 0;
}
