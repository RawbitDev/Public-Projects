// ChessGame - by GitHub.com/RawbitDev
#ifndef CHESS_H
#define CHESS_H

#include <iostream>
#include <ctime>
#include <string>

#include <teamcolor.h>
#include <player.h>
#include <piece.h>
#include <board.h>
using namespace std;

class chess
{

public:
    chess();

};

#endif // CHESS_H
