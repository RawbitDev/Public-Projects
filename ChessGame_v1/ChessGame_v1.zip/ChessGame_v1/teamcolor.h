// ChessGame - by GitHub.com/RawbitDev
#ifndef TEAMCOLOR_H
#define TEAMCOLOR_H

enum teamColor{W=0,B=1,E=2,X=3};
struct position{int posX; int posY;};

#endif // TEAMCOLOR_H
